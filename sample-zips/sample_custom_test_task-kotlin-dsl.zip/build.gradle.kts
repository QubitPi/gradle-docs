plugins {
    id("com.example.custom-test")
}

version = "1.0.2"
