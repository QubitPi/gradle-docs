plugins {
    id("myproject.java-conventions")
    `java-library`
}
