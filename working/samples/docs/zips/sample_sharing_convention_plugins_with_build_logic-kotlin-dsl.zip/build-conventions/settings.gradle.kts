rootProject.name = "build-conventions"
