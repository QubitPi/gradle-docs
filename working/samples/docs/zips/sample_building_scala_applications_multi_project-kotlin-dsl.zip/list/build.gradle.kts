plugins {
    id("buildlogic.scala-library-conventions")
}
