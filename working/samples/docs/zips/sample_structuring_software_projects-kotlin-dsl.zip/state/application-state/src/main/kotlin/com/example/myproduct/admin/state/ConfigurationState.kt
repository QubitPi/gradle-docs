package com.example.myproduct.admin.state

object ConfigurationState {
    val rangeSetting = VersionRangeSetting()
}
