package com.example.myproduct.admin.config

data class VersionRange(
        var fromVersion: String = "",
        var toVersion: String = ""
)
