plugins {
    java
    id("reporters.standard.plugin")
    id("reporters.script.plugin")
}
