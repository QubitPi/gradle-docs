plugins {
    `kotlin-dsl` // <1>
}

repositories {
    gradlePluginPortal() // <2>
}
