plugins {
    id("buildlogic.java-common-conventions") // <1>
    `java-library` // <2>
}
