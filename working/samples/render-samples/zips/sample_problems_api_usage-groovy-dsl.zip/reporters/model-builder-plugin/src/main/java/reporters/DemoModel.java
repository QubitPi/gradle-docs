package reporters;

import java.io.Serializable;

public interface DemoModel extends Serializable {
}
