rootProject.name = "library-publishing"

include(":my-library")
