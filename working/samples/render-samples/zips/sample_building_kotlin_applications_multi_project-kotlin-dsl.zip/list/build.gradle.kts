plugins {
    id("buildlogic.kotlin-library-conventions")
}
