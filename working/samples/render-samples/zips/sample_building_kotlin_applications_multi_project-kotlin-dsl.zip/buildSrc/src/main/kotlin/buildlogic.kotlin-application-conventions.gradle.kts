plugins {
    id("buildlogic.kotlin-common-conventions") // <1>
    application // <2>
}
