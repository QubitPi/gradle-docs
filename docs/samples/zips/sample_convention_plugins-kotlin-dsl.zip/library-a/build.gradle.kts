plugins {
    id("myproject.library-conventions")
}

dependencies {
    implementation(project(":internal-module"))
}
