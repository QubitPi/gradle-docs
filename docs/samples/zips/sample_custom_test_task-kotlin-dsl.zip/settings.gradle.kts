rootProject.name = "custom-test-task"
includeBuild("plugin")
includeBuild("consumer")
