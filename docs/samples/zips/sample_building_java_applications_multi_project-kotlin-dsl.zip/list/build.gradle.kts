plugins {
    id("buildlogic.java-library-conventions")
}
