rootProject.name = "gradle-plugin-in-java"

include("greeting-plugin")
